# Security Policy

Report suspected vulnerabilities privately to the repository owner. Do not publish exploit details before a fix is available.

This repository is an MVP and has not undergone an independent security audit. Do not use it to store highly sensitive personal information or to process payments. Before public launch, add rate limiting, email verification, password recovery, token revocation, trusted-host/CORS configuration, dependency and container scanning, penetration testing, monitoring and an incident-response process.

Never commit `.env`, secrets, credentials, production database exports or personal data.
