const $ = s => document.querySelector(s);
let token = localStorage.getItem("du_token") || "";
let activeNpc = null;
const authHeaders = () => ({ "Content-Type":"application/json", ...(token ? {Authorization:"Bearer "+token} : {}) });
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(url, options={}) {
  const res = await fetch(url, { ...options, headers:{...authHeaders(), ...(options.headers||{})} });
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}
function requireAuth(){ if(!token){ $("#authDialog").showModal(); throw new Error("Sign in to use this feature."); } }
function showStatus(message){ $("#authStatus").textContent=message; }
async function refreshMe(){
  if(!token){ $("#creditCount").textContent="—"; $("#balance").textContent="—"; return; }
  try { const me=await api("/api/me"); $("#creditCount").textContent=me.credits; $("#balance").textContent=me.credits; }
  catch(e){ token=""; localStorage.removeItem("du_token"); }
}
const seedRu = {
  factions:{
    architects:["Архитекторы","Стратеги, создатели и системные мыслители.","Создавай то, что переживёт тебя."],
    wanderers:["Странники","Исследователи, рассказчики и картографы.","Каждая граница — начало."],
    keepers:["Хранители","Кураторы, историки и хранители культуры.","Память — одна из форм силы."],
    makers:["Мастера","Художники, дизайнеры и изобретатели.","Преврати невозможное в реальность."]
  },
  districts:{
    "the-forum":["Форум","Общественная площадь для идей, дискуссий и совместных инициатив."],
    "glass-quarter":["Стеклянный квартал","Район мастерских, галерей и экспериментального искусства."],
    "archive-row":["Архивная улица","Живая библиотека, где воспоминания становятся общей историей."],
    "frontier-docks":["Пограничные доки","Точка отправления экспедиций в неизведанное."]
  },
  roles:{Archivist:"Архивариус",Cartographer:"Картограф",Mediator:"Медиатор",Maker:"Создатель"},
  greetings:{
    mara:"Каждый мир начинается с того, что он решает сохранить.",
    oren:"За пределами карты всегда найдётся новый маршрут.",
    sable:"Сильное сообщество умеет принимать разные мнения.",
    iko:"Что мы сможем создать, если перестанем считать это невозможным?"
  },
  assets:{
    "founders-mark":["Знак основателя","Памятный знак для первых исследователей мира."],
    "forum-seal":["Печать форума","Награда за вклад в общественный диалог."],
    "archive-key":["Ключ архива","Символ заботы об общей памяти."],
    "maker-spark":["Искра мастера","Знак творческого вклада."]
  },
  shop:{"profile-frame":"Обсидиановая рамка","nameplate":"Золотая плашка"}
};
const ruMode=()=>$("#language").value==="ru";
const districtName=d=>ruMode()?(seedRu.districts[d.slug]?.[0]||d.name):d.name;
const districtLore=d=>ruMode()?(seedRu.districts[d.slug]?.[1]||d.lore):d.lore;
async function loadWorld(){
  const w=await api("/api/world"); $("#memberCount").textContent=w.members; $("#districtCount").textContent=w.districts;
  const ds=await api("/api/world/districts"); const map=$("#districtMap"); map.querySelectorAll(".district-pin").forEach(n=>n.remove());
  ds.forEach(d=>{const b=document.createElement("button");b.className="district-pin";b.innerHTML=`<small>SECTOR ${String(d.id).padStart(2,"0")}</small><b>${esc(districtName(d))}</b>`;b.onclick=()=>selectDistrict(d,b);map.append(b);});
  const fs=await api("/api/factions"); $("#factions").replaceChildren();
  fs.forEach(f=>{const loc=ruMode()?seedRu.factions[f.slug]:null;const el=document.createElement("article");el.className="card";el.innerHTML=`<small>FOUNDING FACTION</small><h3>${esc(loc?.[0]||f.name)}</h3><p>${esc(loc?.[1]||f.description)}</p><span class="motto">${esc(loc?.[2]||f.motto)}</span>`;const btn=document.createElement("button");btn.className="outline";btn.textContent="Join circle";btn.onclick=async()=>{try{requireAuth();await api(`/api/factions/${f.id}/join`,{method:"POST"});alert(`Joined ${f.name}`);}catch(e){alert(e.message)}};el.append(btn);$("#factions").append(el);});
}
async function selectDistrict(d,btn){
  document.querySelectorAll(".district-pin").forEach(x=>x.classList.remove("active"));btn.classList.add("active");
  const box=$("#districtDetails");box.innerHTML=`<p class="eyebrow">${ruMode()?"ОТКРЫТЫЙ РАЙОН":"DISCOVERED DISTRICT"}</p><h3>${esc(districtName(d))}</h3><p>${esc(districtLore(d))}</p><p class="muted">${ruMode()?"Награда за исследование":"Exploration reward"}: ${d.reward} WC</p>`;
  const b=document.createElement("button");b.className="gold";b.textContent=ruMode()?"Исследовать район":"Explore district";b.onclick=async()=>{try{requireAuth();const r=await api(`/api/world/districts/${d.id}/explore`,{method:"POST"});alert(r.already_explored?"Already explored.":`+${r.reward} World Credits`);await refreshMe();}catch(e){alert(e.message)}};box.append(b);
}
async function loadNpcs(){
  const xs=await api("/api/npcs");$("#npcList").replaceChildren();
  xs.forEach(n=>{const b=document.createElement("button");b.className="npc-button";b.innerHTML=`<small>${esc(ruMode()?(seedRu.roles[n.role]||n.role):n.role)}</small><b>${esc(n.name)}</b>`;b.onclick=()=>openNpc(n,b);$("#npcList").append(b);});
}
async function openNpc(n,b){
  activeNpc=n;document.querySelectorAll(".npc-button").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#chatTitle").textContent=`${n.name} · ${ruMode()?(seedRu.roles[n.role]||n.role):n.role}`;$("#chatLog").replaceChildren();
  try{requireAuth();const history=await api(`/api/npcs/${n.id}/history`);history.forEach(m=>addBubble(m.speaker,m.body));if(!history.length)addBubble("npc",ruMode()?(seedRu.greetings[n.slug]||n.greeting):n.greeting);}catch(e){addBubble("npc",n.greeting);}
}
function addBubble(speaker,body){const d=document.createElement("div");d.className="bubble "+(speaker==="user"?"user":"");d.innerHTML=`<small>${speaker==="user"?"YOU":esc(activeNpc?.name||"PERSONA")}</small>${esc(body)}`;$("#chatLog").append(d);$("#chatLog").scrollTop=$("#chatLog").scrollHeight;}
$("#chatForm").onsubmit=async e=>{e.preventDefault();try{requireAuth();if(!activeNpc)throw new Error("Choose a persona first.");const message=$("#chatInput").value.trim();if(!message)return;addBubble("user",message);$("#chatInput").value="";const r=await api(`/api/npcs/${activeNpc.id}/chat`,{method:"POST",body:JSON.stringify({message})});addBubble("npc",r.reply);}catch(e){alert(e.message)}};
async function loadProposals(){
  const xs=await api("/api/governance/proposals");const box=$("#proposals");box.replaceChildren();
  if(!xs.length){box.textContent="No open proposals yet. Start the first community discussion.";return;}
  xs.forEach(x=>{const el=document.createElement("article");el.className="proposal";el.innerHTML=`<span class="tag">${esc(x.status.toUpperCase())}</span><h3>${esc(x.title)}</h3><p>${esc(x.body)}</p><small>BY @${esc(x.author)} · ${x.yes} YES / ${x.no} NO</small>`;if(x.status==="open"){const row=document.createElement("div");row.className="vote-row";["yes","no"].forEach(c=>{const b=document.createElement("button");b.className="outline";b.textContent=c.toUpperCase();b.onclick=async()=>{try{requireAuth();await api(`/api/governance/proposals/${x.id}/vote?choice=${c}`,{method:"POST"});await loadProposals();}catch(e){alert(e.message)}};row.append(b)});el.append(row)}box.append(el);});
}
$("#proposalForm").onsubmit=async e=>{e.preventDefault();try{requireAuth();await api("/api/governance/proposals",{method:"POST",body:JSON.stringify({title:$("#proposalTitle").value,body:$("#proposalBody").value})});e.target.reset();await loadProposals();}catch(e){alert(e.message)}};
async function loadAssets(){
  const [all,mine]=await Promise.all([api("/api/assets"),token?api("/api/assets/mine").catch(()=>[]):Promise.resolve([])]);const owned=new Set(mine.map(x=>x.slug));$("#assetGrid").replaceChildren();
  all.forEach(a=>{const loc=ruMode()?seedRu.assets[a.slug]:null;const el=document.createElement("article");el.className="card";el.innerHTML=`<small>${esc(ruMode()?"КОЛЛЕКЦИОННЫЙ ПРЕДМЕТ":a.rarity.toUpperCase()+" COLLECTIBLE")}</small><h3>${esc(loc?.[0]||a.name)}</h3><p>${esc(loc?.[1]||a.description)}</p>`;const b=document.createElement("button");b.className="outline";b.textContent=owned.has(a.slug)?(ruMode()?"Есть":"Owned"):(ruMode()?"Получить":"Claim");b.disabled=owned.has(a.slug);b.onclick=async()=>{try{requireAuth();await api(`/api/assets/${a.slug}/claim`,{method:"POST"});await loadAssets();}catch(e){alert(e.message)}};el.append(b);$("#assetGrid").append(el);});
}
async function loadEconomy(){
  if(!token){$("#balance").textContent="—";$("#ledger").textContent="Sign in to view your ledger.";return}
  const e=await api("/api/economy");$("#balance").textContent=e.credits;$("#creditCount").textContent=e.credits;
  $("#ledger").replaceChildren();e.ledger.forEach(x=>{const row=document.createElement("div");row.className="ledger-item";row.innerHTML=`<span>${esc(x.kind)} · ${esc(x.reference)}</span><b class="${x.amount>=0?"positive":"negative"}">${x.amount>0?"+":""}${x.amount}</b>`;$("#ledger").append(row)});
}
async function loadShop(){
  const xs=await api("/api/economy/shop");$("#shop").replaceChildren();xs.forEach(x=>{const row=document.createElement("div");row.className="shop-item";row.innerHTML=`<span>${esc(ruMode()?(seedRu.shop[x.slug]||x.name):x.name)} · ${x.price} WC</span>`;const b=document.createElement("button");b.className="outline";b.textContent=ruMode()?"Купить":"Buy";b.onclick=async()=>{try{requireAuth();await api(`/api/economy/shop/${x.slug}/buy`,{method:"POST"});await loadEconomy();alert("Purchased.");}catch(e){alert(e.message)}};row.append(b);$("#shop").append(row);});
}
async function loadChronicle(){
  const xs=await api("/api/chronicle");$("#posts").replaceChildren();if(!xs.length){$("#posts").textContent=ruMode()?"Летопись ждёт первую запись.":"The chronicle is waiting for its first entry.";return}
  xs.forEach(x=>{const el=document.createElement("article");el.className="post";el.innerHTML=`<b>@${esc(x.author)}</b><small> · ${new Date(x.created_at).toLocaleString()}</small><p>${esc(x.body)}</p>`;$("#posts").append(el);});
}
$("#postForm").onsubmit=async e=>{e.preventDefault();try{requireAuth();const body=$("#postBody").value.trim();if(!body)return;await api("/api/chronicle",{method:"POST",body:JSON.stringify({body})});$("#postBody").value="";await loadChronicle();await refreshMe();}catch(e){alert(e.message)}};
$("#openAuth").onclick=()=>$("#authDialog").showModal();$("#closeAuth").onclick=()=>$("#authDialog").close();
$("#registerBtn").onclick=async()=>{try{const r=await api("/api/auth/register",{method:"POST",body:JSON.stringify({email:$("#authEmail").value,handle:$("#authHandle").value,password:$("#authPassword").value})});token=r.access_token;localStorage.setItem("du_token",token);$("#authDialog").close();await boot();}catch(e){showStatus(e.message)}};
$("#loginBtn").onclick=async()=>{try{const r=await api("/api/auth/login",{method:"POST",body:JSON.stringify({email:$("#authEmail").value,password:$("#authPassword").value})});token=r.access_token;localStorage.setItem("du_token",token);$("#authDialog").close();await boot();}catch(e){showStatus(e.message)}};
$("#language").onchange=async()=>{applyLanguage($("#language").value);await Promise.all([loadWorld(),loadNpcs(),loadAssets(),loadShop()]);if(!token)return;try{await api("/api/me/preferences",{method:"PUT",body:JSON.stringify({language:$("#language").value})});}catch(e){alert(e.message)}};
async function boot(){
  await loadWorld();await loadNpcs();await loadProposals();await loadAssets();await loadShop();await loadChronicle();await refreshMe();await loadEconomy();
  if(token){try{const p=await api("/api/me/preferences");$("#language").value=p.language;}catch(e){}}
  applyLanguage($("#language").value || "en");
  await Promise.all([loadWorld(),loadNpcs(),loadAssets(),loadShop()]);
}
boot().catch(e=>console.error(e));

const translations = {
  en: {
    "nav1":"World","nav2":"Society","nav3":"Governance","nav4":"Assets","nav5":"Economy",
    "auth":"Sign in","heroEyebrow":"A FICTIONAL SOCIAL SIMULATION · EST. 2026",
    "heroTitle":"POWER IS A<br><em>STORY WE BUILD.</em>",
    "heroLead":"A living digital society of factions, creative alliances, civic imagination and shared history. Your reputation is earned through contribution.",
    "heroCta":"Enter the world ↗","heroMeet":"Meet its voices",
    "worldTitle":"Explore the <em>territory.</em>","worldNote":"A fictional map of places to discover, stories to uncover and communities to join.",
    "circleTitle":"Find your <em>people.</em>","societyTitle":"Meet the <em>voices.</em>",
    "societyNote":"Persistent fictional personas with distinct perspectives and conversational memory.",
    "govTitle":"Shape the <em>commons.</em>","govNote":"Proposals, transparent voting and community decisions. One account, one vote.",
    "proposalTitle":"Submit a proposal","proposalButton":"Submit proposal",
    "assetTitle":"Collect your <em>legacy.</em>","assetNote":"Non-transferable, off-chain collectibles with recorded ownership and provenance.",
    "economyTitle":"Value through <em>contribution.</em>","economyNote":"World Credits are fictional game points. They cannot be transferred, redeemed or exchanged for money.",
    "chronicleTitle":"Write the <em>chronicle.</em>","chronicleNote":"An international, bilingual community space for ideas, updates and creative work.",
    "postButton":"Publish entry","postPlaceholder":"Leave a thought for the chronicle…",
    "chatPlaceholder":"Write a message…","districtPrompt":"Select a district",
    "districtText":"Discover its story and earn a small in-world exploration reward."
  },
  ru: {
    "nav1":"Мир","nav2":"Общество","nav3":"Управление","nav4":"Активы","nav5":"Экономика",
    "auth":"Войти","heroEyebrow":"ВЫМЫШЛЕННАЯ СОЦИАЛЬНАЯ СИМУЛЯЦИЯ · 2026",
    "heroTitle":"СИЛА — ЭТО<br><em>ИСТОРИЯ, КОТОРУЮ МЫ СОЗДАЁМ.</em>",
    "heroLead":"Живое цифровое общество фракций, творческих союзов, гражданских инициатив и общей истории. Репутация зарабатывается вкладом в сообщество.",
    "heroCta":"Войти в мир ↗","heroMeet":"Голоса мира",
    "worldTitle":"Исследуй <em>территории.</em>","worldNote":"Вымышленная карта мест, историй и сообществ для открытия.",
    "circleTitle":"Найди <em>своих.</em>","societyTitle":"Познакомься с <em>голосами.</em>",
    "societyNote":"Персонажи с индивидуальными взглядами и памятью диалогов.",
    "govTitle":"Формируй <em>общее пространство.</em>","govNote":"Предложения, прозрачное голосование и решения сообщества. Один аккаунт — один голос.",
    "proposalTitle":"Внести предложение","proposalButton":"Отправить предложение",
    "assetTitle":"Собери своё <em>наследие.</em>","assetNote":"Непередаваемые цифровые коллекционные предметы с историей владения.",
    "economyTitle":"Ценность через <em>вклад.</em>","economyNote":"World Credits — вымышленные игровые баллы. Их нельзя передавать, обменивать или выводить в деньги.",
    "chronicleTitle":"Пиши <em>летопись.</em>","chronicleNote":"Международное двуязычное пространство для идей, новостей и творчества.",
    "postButton":"Опубликовать","postPlaceholder":"Оставь запись в летописи…",
    "chatPlaceholder":"Напиши сообщение…","districtPrompt":"Выбери район",
    "districtText":"Узнай его историю и получи небольшой игровой бонус за исследование."
  }
};
function applyLanguage(lang){
  const t=translations[lang]||translations.en;
  const set=(sel,key,html=false)=>{const el=$(sel);if(el){if(html)el.innerHTML=t[key];else el.textContent=t[key];}};
  ["World","Society","Governance","Assets","Economy"].forEach((k,i)=>{const el=document.querySelector(`nav a:nth-child(${i+1})`);if(el)el.textContent=t["nav"+(i+1)]});
  set("#openAuth","auth");set(".hero .eyebrow","heroEyebrow");set(".hero h1","heroTitle",true);
  set(".hero .lead","heroLead");set(".hero .gold","heroCta");set(".hero .textlink","heroMeet");
  set("#world .section-head:not(.compact) h2","worldTitle",true);set("#world .section-note","worldNote");
  set("#world .compact h2","circleTitle",true);set("#society .section-head h2","societyTitle",true);set("#society .section-note","societyNote");
  set("#governance .section-head h2","govTitle",true);set("#governance .section-note","govNote");
  set("#proposalForm h3","proposalTitle");set("#proposalForm button","proposalButton");
  set("#assets .section-head h2","assetTitle",true);set("#assets .section-note","assetNote");
  set("#economy .section-head h2","economyTitle",true);set("#economy .section-note","economyNote");
  set("#chronicle .section-head h2","chronicleTitle",true);set("#chronicle .section-note","chronicleNote");
  set("#postForm button","postButton");$("#postBody").placeholder=t.postPlaceholder;$("#chatInput").placeholder=t.chatPlaceholder;
  const district=$("#districtDetails");if(district&&!district.querySelector("button")){district.querySelector("h3").textContent=t.districtPrompt;district.querySelector("p:last-child").textContent=t.districtText;}
}
