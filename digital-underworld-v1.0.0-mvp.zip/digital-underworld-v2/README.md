# DIGITAL UNDERWORLD — THE NEW WORLD

A fictional international social-simulation platform. Six MVP layers are implemented:
1. WORLD 2.0 — districts, exploration, factions and world profile.
2. AI SOCIETY — persistent NPC personas, chat history and a deterministic local persona engine (no external AI service).
3. GOVERNANCE — proposals, one-person-one-vote polls, moderation reports and audit records.
4. DIGITAL ASSETS — collectible badges, claim/ownership records and provenance events. Off-chain, non-transferable.
5. GLOBAL ECONOMY — fictional credits, append-only earning ledger, cosmetic shop. Credits are non-transferable, non-redeemable and have no cash value.
6. GLOBAL ACCESS — responsive bilingual English/Russian UI, accounts and REST API.

This is a fictional community product, not an operating layer for a real criminal organization. It does not support real-world coercion, extortion, violence, illicit trade or criminal coordination.

## Run
```bash
cp .env.example .env
docker compose up --build
```
Open http://localhost:8000 and /docs for API documentation. Without Docker: `pip install -r requirements.txt && uvicorn app.main:app --reload` (SQLite default; Compose uses PostgreSQL 16).

## Admin
Register normally, then promote an account to role `admin` through a secured database session. No public admin-bootstrap route or default admin credentials are included.

## Production hardening still required
Use a strong unique SECRET_KEY; managed PostgreSQL with encrypted backups/PITR; HTTPS; CORS allowlist and trusted hosts; rate limiting/bot protection; email verification/password reset; migrations; observability/alerting; SAST/DAST and penetration testing; load testing; privacy/terms/age/accessibility review; staffed moderation and incident response. This is an MVP codebase, not an independently audited production system.

No live blockchain deployment, token sale, external LLM, payments, or public hosting is included.
