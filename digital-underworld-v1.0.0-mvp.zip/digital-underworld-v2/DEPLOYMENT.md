# Deployment notes

## Render
1. Push this repository to GitHub.
2. In Render, create a managed PostgreSQL database in the same region as the web service.
3. Create a Web Service from the GitHub repository and select Docker runtime.
4. Set `DATABASE_URL` to the database's internal connection string (SQLAlchemy form: `postgresql+psycopg://...`).
5. Set `SECRET_KEY` to a unique random secret of at least 32 bytes.
6. Deploy and verify `/health` and `/docs`.
7. Enable backups, alerts, and log retention; verify a database restore before public launch.

Do not use the local Docker Compose password or development SECRET_KEY in production. Paid infrastructure may incur charges; review pricing before provisioning.
