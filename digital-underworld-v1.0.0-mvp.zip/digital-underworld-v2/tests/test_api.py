import os
from pathlib import Path

TEST_DB = Path("test_underworld.sqlite")
if TEST_DB.exists():
    TEST_DB.unlink()
os.environ["DATABASE_URL"] = "sqlite:///./test_underworld.sqlite"
os.environ["SECRET_KEY"] = "test-only-secret-key-with-enough-entropy-for-tests"

from fastapi.testclient import TestClient
from app.main import app

def test_full_mvp_happy_path():
    with TestClient(app) as client:
        assert client.get("/health").json()["status"] == "ok"
        world = client.get("/api/world").json()
        assert world["districts"] == 4
        assert world["factions"] == 4

        registered = client.post("/api/auth/register", json={
            "email": "mvp-test@example.com", "handle": "mvp_tester",
            "password": "a-very-long-test-password"
        })
        assert registered.status_code == 201
        token = registered.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        login = client.post("/api/auth/login", json={
            "email": "mvp-test@example.com", "password": "a-very-long-test-password"
        })
        assert login.status_code == 200
        assert client.get("/api/me", headers={"Authorization": "Bearer invalid"}).status_code == 401
        assert client.put("/api/me/preferences", headers=headers, json={"language": "ru"}).json()["language"] == "ru"

        me = client.get("/api/me", headers=headers)
        assert me.status_code == 200
        assert me.json()["credits"] == 100

        district = client.post("/api/world/districts/1/explore", headers=headers)
        assert district.status_code == 200
        assert district.json()["reward"] == 5
        assert client.post("/api/world/districts/1/explore", headers=headers).json()["already_explored"] is True

        npc = client.get("/api/npcs").json()[0]
        reply = client.post(f"/api/npcs/{npc['id']}/chat", headers=headers,
                            json={"message": "Can you help me with an idea?"})
        assert reply.status_code == 200
        assert "Давай" in reply.json()["reply"]

        proposal = client.post("/api/governance/proposals", headers=headers, json={
            "title": "Improve the public archive",
            "body": "Create a monthly volunteer review of the fictional world archive."
        })
        assert proposal.status_code == 201
        proposal_id = proposal.json()["id"]
        assert client.post(f"/api/governance/proposals/{proposal_id}/vote?choice=yes",
                           headers=headers).status_code == 200
        assert client.post(f"/api/governance/proposals/{proposal_id}/vote?choice=no",
                           headers=headers).status_code == 409
        assert client.post("/api/economy/earn?action=council_proposal", headers=headers).status_code == 200

        post = client.post("/api/chronicle", headers=headers,
                           json={"body": "A first note for the community chronicle."})
        assert post.status_code == 201
        assert client.get("/api/chronicle").json()[0]["body"].startswith("A first")
        reward = client.post("/api/economy/earn?action=community_post", headers=headers)
        assert reward.status_code == 200 and reward.json()["earned"] == 2
        assert client.post("/api/economy/earn?action=community_post", headers=headers).status_code == 409

        mine = client.get("/api/assets/mine", headers=headers)
        assert mine.status_code == 200
        assert any(x["slug"] == "founders-mark" for x in mine.json())

        economy = client.get("/api/economy", headers=headers)
        assert economy.status_code == 200
        assert economy.json()["credits"] >= 112
        purchase = client.post("/api/economy/shop/profile-frame/buy", headers=headers)
        assert purchase.status_code == 200
        assert client.get("/").status_code == 200
        assert client.get("/static/app.js").status_code == 200
