import os, base64, hashlib, hmac, json, secrets
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Integer, DateTime, ForeignKey, Text, Boolean, UniqueConstraint, select, desc, func
from sqlalchemy.orm import DeclarativeBase, sessionmaker, Mapped, mapped_column, relationship, Session

DB_URL = os.getenv("DATABASE_URL", "sqlite:///./underworld.db")
engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if DB_URL.startswith("sqlite") else {}, pool_pre_ping=True)
SessionLocal = sessionmaker(engine, autoflush=False, autocommit=False)
SECRET = os.getenv("SECRET_KEY", "development-secret-change-before-public-launch")
TOKEN_MINUTES = int(os.getenv("ACCESS_TOKEN_MINUTES", "720"))
if os.getenv("ENVIRONMENT") == "production" and (len(SECRET) < 32 or SECRET.startswith("development")):
    raise RuntimeError("Set a unique SECRET_KEY of at least 32 characters in production")
class Base(DeclarativeBase): pass
class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(254), unique=True, index=True)
    handle: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(16), default="member")
    faction_id: Mapped[int | None] = mapped_column(ForeignKey("factions.id"), nullable=True)
    reputation: Mapped[int] = mapped_column(Integer, default=0)
    credits: Mapped[int] = mapped_column(Integer, default=100)
    language: Mapped[str] = mapped_column(String(5), default="en")
    faction = relationship("Faction")
class Faction(Base):
    __tablename__ = "factions"
    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(80))
    motto: Mapped[str] = mapped_column(String(180))
    description: Mapped[str] = mapped_column(Text)
    accent: Mapped[str] = mapped_column(String(20))
class District(Base):
    __tablename__ = "districts"
    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(80))
    lore: Mapped[str] = mapped_column(Text)
    x: Mapped[int] = mapped_column(Integer)
    y: Mapped[int] = mapped_column(Integer)
    discovery_reward: Mapped[int] = mapped_column(Integer, default=5)
class NPC(Base):
    __tablename__ = "npcs"
    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(80))
    role: Mapped[str] = mapped_column(String(80))
    persona: Mapped[str] = mapped_column(Text)
    greeting: Mapped[str] = mapped_column(Text)
class ChatMessage(Base):
    __tablename__ = "chat_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    npc_id: Mapped[int] = mapped_column(ForeignKey("npcs.id"))
    speaker: Mapped[str] = mapped_column(String(12))
    body: Mapped[str] = mapped_column(String(1200))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
class Proposal(Base):
    __tablename__ = "proposals"
    id: Mapped[int] = mapped_column(primary_key=True)
    author_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    title: Mapped[str] = mapped_column(String(140))
    body: Mapped[str] = mapped_column(String(2000))
    status: Mapped[str] = mapped_column(String(16), default="open")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    author = relationship("User")
class Vote(Base):
    __tablename__ = "votes"
    __table_args__ = (UniqueConstraint("proposal_id", "user_id", name="uq_vote_user_proposal"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    proposal_id: Mapped[int] = mapped_column(ForeignKey("proposals.id"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    choice: Mapped[str] = mapped_column(String(8))
class Asset(Base):
    __tablename__ = "assets"
    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(48), unique=True)
    name: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(String(500))
    rarity: Mapped[str] = mapped_column(String(20))
class AssetClaim(Base):
    __tablename__ = "asset_claims"
    __table_args__ = (UniqueConstraint("asset_id", "user_id", name="uq_asset_owner"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    claimed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    asset = relationship("Asset")
class LedgerEntry(Base):
    __tablename__ = "ledger"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    amount: Mapped[int] = mapped_column(Integer)
    kind: Mapped[str] = mapped_column(String(24))
    reference: Mapped[str] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
class Post(Base):
    __tablename__ = "posts"
    id: Mapped[int] = mapped_column(primary_key=True)
    author_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    body: Mapped[str] = mapped_column(String(1200))
    hidden: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    author = relationship("User")
class Report(Base):
    __tablename__ = "reports"
    id: Mapped[int] = mapped_column(primary_key=True)
    reporter_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    target_type: Mapped[str] = mapped_column(String(20))
    target_id: Mapped[int] = mapped_column(Integer)
    reason: Mapped[str] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(16), default="open")
class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    actor_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    action: Mapped[str] = mapped_column(String(80))
    object_type: Mapped[str] = mapped_column(String(40))
    object_id: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

class RegisterIn(BaseModel):
    email: str = Field(pattern=r"^[^@\s]+@[^\s@]+\.[^\s@]+$")
    handle: str = Field(min_length=3, max_length=32, pattern=r"^[A-Za-z0-9_]+$")
    password: str = Field(min_length=12, max_length=128)
class LoginIn(BaseModel):
    email: str = Field(pattern=r"^[^@\s]+@[^\s@]+\.[^\s@]+$")
    password: str
class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=1200)
class ProposalIn(BaseModel):
    title: str = Field(min_length=8, max_length=140)
    body: str = Field(min_length=20, max_length=2000)
class ReportIn(BaseModel):
    target_type: str = Field(pattern="^(post|proposal|user)$")
    target_id: int = Field(gt=0)
    reason: str = Field(min_length=8, max_length=500)
class LanguageIn(BaseModel):
    language: str = Field(pattern="^(en|ru)$")

def b64u(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")

def unb64u(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))

def hash_password(password: str) -> str:
    rounds = 600_000
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, rounds)
    return f"pbkdf2_sha256${rounds}${b64u(salt)}${b64u(digest)}"

def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, rounds, salt, expected = stored.split("$", 3)
        if scheme != "pbkdf2_sha256": return False
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), unb64u(salt), int(rounds))
        return hmac.compare_digest(b64u(actual), expected)
    except (ValueError, TypeError):
        return False

def issue_token(uid: int) -> str:
    payload = {"sub": str(uid), "exp": int((datetime.now(timezone.utc) + timedelta(minutes=TOKEN_MINUTES)).timestamp())}
    head = b64u(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    body = b64u(json.dumps(payload, separators=(",", ":")).encode())
    signature = b64u(hmac.new(SECRET.encode(), f"{head}.{body}".encode(), hashlib.sha256).digest())
    return f"{head}.{body}.{signature}"

def decode_token(token: str) -> dict:
    head, body, signature = token.split(".")
    expected = b64u(hmac.new(SECRET.encode(), f"{head}.{body}".encode(), hashlib.sha256).digest())
    if not hmac.compare_digest(signature, expected): raise ValueError("Invalid signature")
    payload = json.loads(unb64u(body))
    if int(payload.get("exp", 0)) < int(datetime.now(timezone.utc).timestamp()): raise ValueError("Expired token")
    return payload
def current_user(authorization: str | None = Header(default=None), db: Session = Depends(get_db)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Authentication required")
    try: uid = int(decode_token(authorization[7:])["sub"])
    except (ValueError, KeyError, json.JSONDecodeError): raise HTTPException(401, "Invalid or expired token")
    user = db.get(User, uid)
    if not user: raise HTTPException(401, "User not found")
    return user
def admin_user(user: User = Depends(current_user)):
    if user.role != "admin": raise HTTPException(403, "Administrator role required")
    return user

def audit(db: Session, actor: int | None, action: str, obj: str, oid: int):
    db.add(AuditEvent(actor_id=actor, action=action, object_type=obj, object_id=oid))

def initialize_db():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if not db.scalar(select(Faction.id).limit(1)):
            db.add_all([
                Faction(slug="architects", name="The Architects", motto="Build what outlasts you.", description="Strategists, builders and systems thinkers.", accent="#c8a96b"),
                Faction(slug="wanderers", name="The Wanderers", motto="Every border is a beginning.", description="Explorers, storytellers and mapmakers.", accent="#78a6a3"),
                Faction(slug="keepers", name="The Keepers", motto="Memory is a form of power.", description="Curators, historians and cultural stewards.", accent="#9b86bd"),
                Faction(slug="makers", name="The Makers", motto="Make the impossible tangible.", description="Artists, designers and inventors.", accent="#d18b73"),
            ])
            db.add_all([
                District(slug="the-forum", name="The Forum", lore="A public square for ideas, debate and civic imagination.", x=1, y=1, discovery_reward=5),
                District(slug="glass-quarter", name="Glass Quarter", lore="A district of studios, galleries and experimental craft.", x=2, y=1, discovery_reward=8),
                District(slug="archive-row", name="Archive Row", lore="A living library where memories become shared history.", x=1, y=2, discovery_reward=8),
                District(slug="frontier-docks", name="Frontier Docks", lore="A launch point for expeditions into the unknown.", x=2, y=2, discovery_reward=10),
            ])
            db.add_all([
                NPC(slug="mara", name="Mara Voss", role="Archivist", persona="Thoughtful, precise, values memory and context.", greeting="Every world begins with what it chooses to remember."),
                NPC(slug="oren", name="Oren Vale", role="Cartographer", persona="Curious, adventurous, asks exploratory questions.", greeting="There is always another route beyond the map."),
                NPC(slug="sable", name="Sable Ren", role="Mediator", persona="Calm, fair, values consent and constructive dialogue.", greeting="A strong community makes room for disagreement."),
                NPC(slug="iko", name="Iko", role="Maker", persona="Playful, inventive, values experimentation.", greeting="What could we make if we stopped assuming it was impossible?"),
            ])
            db.add_all([
                Asset(slug="founders-mark", name="Founder's Mark", description="A commemorative mark for early world explorers.", rarity="common"),
                Asset(slug="forum-seal", name="Forum Seal", description="A badge earned by contributing to civic dialogue.", rarity="uncommon"),
                Asset(slug="archive-key", name="Archive Key", description="A symbol of stewardship and shared memory.", rarity="rare"),
                Asset(slug="maker-spark", name="Maker Spark", description="A mark of creative contribution.", rarity="uncommon"),
            ])
            db.commit()

@asynccontextmanager
async def lifespan(application: FastAPI):
    initialize_db()
    yield

app = FastAPI(title="DIGITAL UNDERWORLD — THE NEW WORLD", version="1.0.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", response_class=HTMLResponse)
def home():
    return open("static/index.html", encoding="utf-8").read()

@app.get("/health")
def health():
    return {"status": "ok", "service": "digital-underworld", "version": "1.0.0"}

@app.post("/api/auth/register", status_code=201)
def register(p: RegisterIn, db: Session = Depends(get_db)):
    if db.scalar(select(User).where((User.email == p.email.lower()) | (User.handle == p.handle))):
        raise HTTPException(409, "Email or handle already registered")
    u = User(email=p.email.lower(), handle=p.handle, password_hash=hash_password(p.password))
    db.add(u)
    db.flush()
    db.add(LedgerEntry(user_id=u.id, amount=100, kind="welcome", reference="initial-balance"))
    db.add(AssetClaim(asset_id=db.scalar(select(Asset.id).where(Asset.slug == "founders-mark")), user_id=u.id))
    audit(db, u.id, "account.created", "user", u.id)
    db.commit()
    return {"access_token": issue_token(u.id), "token_type": "bearer"}

@app.post("/api/auth/login")
def login(p: LoginIn, db: Session = Depends(get_db)):
    u = db.scalar(select(User).where(User.email == p.email.lower()))
    if not u or not verify_password(p.password, u.password_hash):
        raise HTTPException(401, "Incorrect email or password")
    return {"access_token": issue_token(u.id), "token_type": "bearer"}

@app.get("/api/me")
def me(u: User = Depends(current_user)):
    return {"id": u.id, "email": u.email, "handle": u.handle, "role": u.role,
            "reputation": u.reputation, "credits": u.credits, "faction_id": u.faction_id,
            "language": u.language}

@app.get("/api/me/preferences")
def get_preferences(u: User = Depends(current_user)):
    return {"language": u.language}

@app.put("/api/me/preferences")
def set_preferences(p: LanguageIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    u.language = p.language
    db.commit()
    return {"language": u.language}

# STAGE 1 — WORLD 2.0
@app.get("/api/world")
def world(db: Session = Depends(get_db)):
    return {"name": "DIGITAL UNDERWORLD", "members": db.query(User).count(),
            "districts": db.query(District).count(), "factions": db.query(Faction).count()}

@app.get("/api/world/districts")
def districts(db: Session = Depends(get_db)):
    rows = db.scalars(select(District).order_by(District.id)).all()
    return [{"id": d.id, "slug": d.slug, "name": d.name, "lore": d.lore,
             "x": d.x, "y": d.y, "reward": d.discovery_reward} for d in rows]

@app.post("/api/world/districts/{district_id}/explore")
def explore(district_id: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    d = db.get(District, district_id)
    if not d: raise HTTPException(404, "District not found")
    reference = f"explore:{d.slug}"
    already = db.scalar(select(LedgerEntry.id).where(LedgerEntry.user_id == u.id, LedgerEntry.reference == reference))
    if already: return {"district": d.name, "already_explored": True, "credits": u.credits}
    u.credits += d.discovery_reward
    u.reputation += 1
    db.add(LedgerEntry(user_id=u.id, amount=d.discovery_reward, kind="exploration", reference=reference))
    audit(db, u.id, "district.explored", "district", d.id)
    db.commit()
    return {"district": d.name, "reward": d.discovery_reward, "credits": u.credits}

@app.get("/api/factions")
def factions(db: Session = Depends(get_db)):
    return [{"id": f.id, "slug": f.slug, "name": f.name, "motto": f.motto,
             "description": f.description, "accent": f.accent} for f in db.scalars(select(Faction).order_by(Faction.id)).all()]

@app.post("/api/factions/{faction_id}/join")
def join_faction(faction_id: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    f = db.get(Faction, faction_id)
    if not f: raise HTTPException(404, "Faction not found")
    u.faction_id = f.id
    audit(db, u.id, "faction.joined", "faction", f.id)
    db.commit()
    return {"joined": f.name}

# STAGE 2 — AI SOCIETY (local deterministic persona simulation)
def npc_reply(npc: NPC, message: str, memory: list[str], language: str = "en") -> str:
    m = message.lower()
    if language == "ru":
        greetings = {"mara": "Каждый мир начинается с того, что он решает сохранить.",
                     "oren": "За пределами карты всегда найдётся новый маршрут.",
                     "sable": "Сильное сообщество умеет принимать разные мнения.",
                     "iko": "Что мы сможем создать, если перестанем считать это невозможным?"}
        if any(k in m for k in ["hello", "hi", "привет", "здравствуй"]):
            return greetings.get(npc.slug, "Рад встрече. О чём поговорим?")
        if any(k in m for k in ["help", "idea", "помоги", "идея"]):
            return f"{npc.name}: Давай превратим это в один понятный следующий шаг. Какой результат будет полезен сообществу?"
        if any(k in m for k in ["conflict", "disagree", "спор", "конфликт"]):
            return "Давай отделим людей от проблемы. Опиши последствия, выслушай другую точку зрения и предложи справедливое решение."
        if memory:
            return f"{npc.name}: Помню, мы обсуждали: {memory[-1][:100]}. Твоя новая мысль добавляет ещё одну нить. Что исследуем дальше?"
        return f"{npc.name}: {npc.persona} Расскажи, что ты хочешь создать в этом мире."
    if any(k in m for k in ["hello", "hi", "привет", "здравствуй"]):
        return npc.greeting
    if any(k in m for k in ["help", "idea", "помоги", "идея"]):
        return f"{npc.name}: Let's turn that into one clear next step. What outcome would make this meaningful to the community?"
    if any(k in m for k in ["conflict", "disagree", "спор", "конфликт"]):
        return "Let's separate the people from the problem. State the impact, listen to the other view, and propose a fair remedy."
    if memory:
        return f"{npc.name}: I remember we discussed: {memory[-1][:100]}. Your new thought adds another thread. What would you like to explore next?"
    return f"{npc.name}: {npc.persona} Tell me more about what you want to create in this world."

@app.get("/api/npcs")
def list_npcs(db: Session = Depends(get_db)):
    return [{"id": n.id, "slug": n.slug, "name": n.name, "role": n.role, "greeting": n.greeting}
            for n in db.scalars(select(NPC).order_by(NPC.id)).all()]

@app.post("/api/npcs/{npc_id}/chat")
def chat(npc_id: int, p: ChatIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    npc = db.get(NPC, npc_id)
    if not npc: raise HTTPException(404, "Persona not found")
    previous = db.scalars(select(ChatMessage).where(ChatMessage.user_id == u.id, ChatMessage.npc_id == npc.id).order_by(ChatMessage.id)).all()
    memory = [x.body for x in previous if x.speaker == "user"][-5:]
    db.add(ChatMessage(user_id=u.id, npc_id=npc.id, speaker="user", body=p.message))
    answer = npc_reply(npc, p.message, memory, u.language)
    db.add(ChatMessage(user_id=u.id, npc_id=npc.id, speaker="npc", body=answer))
    audit(db, u.id, "npc.message", "npc", npc.id)
    db.commit()
    return {"npc": npc.name, "reply": answer, "memory_items": len(memory) + 1}

@app.get("/api/npcs/{npc_id}/history")
def npc_history(npc_id: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    if not db.get(NPC, npc_id): raise HTTPException(404, "Persona not found")
    xs = db.scalars(select(ChatMessage).where(ChatMessage.user_id == u.id, ChatMessage.npc_id == npc_id).order_by(ChatMessage.id).limit(100)).all()
    return [{"speaker": x.speaker, "body": x.body, "created_at": x.created_at.isoformat()} for x in xs]

# STAGE 3 — GOVERNANCE
@app.get("/api/governance/proposals")
def proposals(db: Session = Depends(get_db)):
    xs = db.scalars(select(Proposal).order_by(desc(Proposal.created_at))).all()
    out = []
    for x in xs:
        yes = db.scalar(select(func.count(Vote.id)).where(Vote.proposal_id == x.id, Vote.choice == "yes")) or 0
        no = db.scalar(select(func.count(Vote.id)).where(Vote.proposal_id == x.id, Vote.choice == "no")) or 0
        out.append({"id": x.id, "title": x.title, "body": x.body, "author": x.author.handle,
                    "status": x.status, "yes": yes, "no": no, "created_at": x.created_at.isoformat()})
    return out

@app.post("/api/governance/proposals", status_code=201)
def create_proposal(p: ProposalIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    x = Proposal(author_id=u.id, title=p.title, body=p.body)
    db.add(x)
    db.flush()
    audit(db, u.id, "proposal.created", "proposal", x.id)
    db.commit()
    return {"id": x.id, "status": x.status}

@app.post("/api/governance/proposals/{proposal_id}/vote")
def vote(proposal_id: int, choice: str, u: User = Depends(current_user), db: Session = Depends(get_db)):
    if choice not in ("yes", "no"): raise HTTPException(422, "Choice must be yes or no")
    x = db.get(Proposal, proposal_id)
    if not x: raise HTTPException(404, "Proposal not found")
    if x.status != "open": raise HTTPException(409, "Voting is closed")
    if db.scalar(select(Vote.id).where(Vote.proposal_id == x.id, Vote.user_id == u.id)):
        raise HTTPException(409, "You have already voted")
    db.add(Vote(proposal_id=x.id, user_id=u.id, choice=choice))
    audit(db, u.id, "proposal.voted", "proposal", x.id)
    db.commit()
    return {"proposal_id": x.id, "choice": choice}

@app.post("/api/governance/proposals/{proposal_id}/close")
def close_proposal(proposal_id: int, u: User = Depends(admin_user), db: Session = Depends(get_db)):
    x = db.get(Proposal, proposal_id)
    if not x: raise HTTPException(404, "Proposal not found")
    x.status = "closed"
    audit(db, u.id, "proposal.closed", "proposal", x.id)
    db.commit()
    return {"status": "closed"}

# STAGE 4 — DIGITAL ASSETS (off-chain, non-transferable collectibles)
@app.get("/api/assets")
def assets(db: Session = Depends(get_db)):
    return [{"slug": a.slug, "name": a.name, "description": a.description, "rarity": a.rarity}
            for a in db.scalars(select(Asset).order_by(Asset.id)).all()]

@app.get("/api/assets/mine")
def my_assets(u: User = Depends(current_user), db: Session = Depends(get_db)):
    xs = db.scalars(select(AssetClaim).where(AssetClaim.user_id == u.id).order_by(AssetClaim.claimed_at)).all()
    return [{"slug": x.asset.slug, "name": x.asset.name, "rarity": x.asset.rarity,
             "claimed_at": x.claimed_at.isoformat(), "owner_handle": u.handle} for x in xs]

@app.post("/api/assets/{slug}/claim")
def claim_asset(slug: str, u: User = Depends(current_user), db: Session = Depends(get_db)):
    a = db.scalar(select(Asset).where(Asset.slug == slug))
    if not a: raise HTTPException(404, "Collectible not found")
    if db.scalar(select(AssetClaim.id).where(AssetClaim.asset_id == a.id, AssetClaim.user_id == u.id)):
        raise HTTPException(409, "Already claimed")
    # The two achievement collectibles are earned through contribution milestones.
    if slug == "forum-seal" and u.reputation < 3: raise HTTPException(403, "Requires 3 reputation")
    if slug == "maker-spark" and u.reputation < 5: raise HTTPException(403, "Requires 5 reputation")
    if slug == "archive-key" and u.reputation < 8: raise HTTPException(403, "Requires 8 reputation")
    x = AssetClaim(asset_id=a.id, user_id=u.id)
    db.add(x)
    db.flush()
    audit(db, u.id, "asset.claimed", "asset", a.id)
    db.commit()
    return {"claimed": a.slug, "name": a.name, "provenance_id": x.id}

# STAGE 5 — GLOBAL ECONOMY (game credits only)
@app.get("/api/economy")
def economy(u: User = Depends(current_user), db: Session = Depends(get_db)):
    xs = db.scalars(select(LedgerEntry).where(LedgerEntry.user_id == u.id).order_by(desc(LedgerEntry.created_at)).limit(50)).all()
    return {"credits": u.credits, "currency": "WORLD_CREDITS (fictional; no cash value)",
            "ledger": [{"amount": x.amount, "kind": x.kind, "reference": x.reference, "created_at": x.created_at.isoformat()} for x in xs]}

@app.post("/api/economy/earn")
def earn(action: str, u: User = Depends(current_user), db: Session = Depends(get_db)):
    rewards = {"community_post": 2, "council_proposal": 5}
    if action not in rewards: raise HTTPException(422, "Unsupported earning action")
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    if action == "community_post":
        contributed = db.scalar(select(Post.id).where(Post.author_id == u.id, Post.created_at >= today_start).limit(1))
    else:
        contributed = db.scalar(select(Proposal.id).where(Proposal.author_id == u.id, Proposal.created_at >= today_start).limit(1))
    if not contributed:
        raise HTTPException(409, "Complete the matching contribution before claiming this reward")
    ref = f"reward:{action}:{datetime.now(timezone.utc).date().isoformat()}"
    if db.scalar(select(LedgerEntry.id).where(LedgerEntry.user_id == u.id, LedgerEntry.reference == ref)):
        raise HTTPException(409, "Daily reward already claimed")
    amount = rewards[action]
    u.credits += amount
    db.add(LedgerEntry(user_id=u.id, amount=amount, kind="contribution", reference=ref))
    audit(db, u.id, "economy.rewarded", "user", u.id)
    db.commit()
    return {"earned": amount, "credits": u.credits}

SHOP = {"profile-frame": {"name": "Obsidian Frame", "price": 20},
        "nameplate": {"name": "Gold Nameplate", "price": 35}}
@app.get("/api/economy/shop")
def shop():
    return [{"slug": k, **v} for k, v in SHOP.items()]

@app.post("/api/economy/shop/{slug}/buy")
def buy(slug: str, u: User = Depends(current_user), db: Session = Depends(get_db)):
    item = SHOP.get(slug)
    if not item: raise HTTPException(404, "Shop item not found")
    ref = f"shop:{slug}"
    if db.scalar(select(LedgerEntry.id).where(LedgerEntry.user_id == u.id, LedgerEntry.reference == ref)):
        raise HTTPException(409, "Already purchased")
    if u.credits < item["price"]: raise HTTPException(409, "Insufficient credits")
    u.credits -= item["price"]
    db.add(LedgerEntry(user_id=u.id, amount=-item["price"], kind="purchase", reference=ref))
    audit(db, u.id, "economy.purchase", "shop_item", 0)
    db.commit()
    return {"purchased": item["name"], "credits": u.credits}

# Community safety and admin moderation
@app.post("/api/reports", status_code=201)
def report(p: ReportIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    x = Report(reporter_id=u.id, target_type=p.target_type, target_id=p.target_id, reason=p.reason)
    db.add(x)
    db.flush()
    audit(db, u.id, "content.reported", p.target_type, p.target_id)
    db.commit()
    return {"status": "received", "report_id": x.id}

@app.get("/api/admin/reports")
def admin_reports(_: User = Depends(admin_user), db: Session = Depends(get_db)):
    xs = db.scalars(select(Report).order_by(desc(Report.id))).all()
    return [{"id": x.id, "target_type": x.target_type, "target_id": x.target_id,
             "reason": x.reason, "status": x.status} for x in xs]

@app.get("/api/admin/audit")
def admin_audit(_: User = Depends(admin_user), db: Session = Depends(get_db)):
    xs = db.scalars(select(AuditEvent).order_by(desc(AuditEvent.id)).limit(200)).all()
    return [{"actor_id": x.actor_id, "action": x.action, "object_type": x.object_type,
             "object_id": x.object_id, "created_at": x.created_at.isoformat()} for x in xs]

@app.get("/api/admin/users")
def admin_users(_: User = Depends(admin_user), db: Session = Depends(get_db)):
    xs = db.scalars(select(User).order_by(User.id).limit(200)).all()
    return [{"id": x.id, "handle": x.handle, "email": x.email, "role": x.role,
             "reputation": x.reputation, "credits": x.credits} for x in xs]

# Public chronicle
class PostIn(BaseModel):
    body: str = Field(min_length=1, max_length=1200)

@app.get("/api/chronicle")
def chronicle(db: Session = Depends(get_db)):
    xs = db.scalars(select(Post).where(Post.hidden.is_(False)).order_by(desc(Post.created_at)).limit(50)).all()
    return [{"id": x.id, "author": x.author.handle, "body": x.body,
             "created_at": x.created_at.isoformat()} for x in xs]

@app.post("/api/chronicle", status_code=201)
def create_post(p: PostIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    x = Post(author_id=u.id, body=p.body.strip())
    db.add(x)
    u.reputation += 1
    db.flush()
    audit(db, u.id, "chronicle.posted", "post", x.id)
    db.commit()
    return {"id": x.id, "reputation": u.reputation}

@app.post("/api/admin/posts/{post_id}/hide")
def hide_post(post_id: int, u: User = Depends(admin_user), db: Session = Depends(get_db)):
    x = db.get(Post, post_id)
    if not x: raise HTTPException(404, "Post not found")
    x.hidden = True
    audit(db, u.id, "post.hidden", "post", x.id)
    db.commit()
    return {"hidden": True}
